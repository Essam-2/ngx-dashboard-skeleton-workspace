import * as i0 from '@angular/core';
import { InjectionToken, Input, Optional, Inject, Component, Directive } from '@angular/core';

const DEFAULT_SKELETON_CONFIG = {
    animationDuration: '1.4s',
    baseColor: 'var(--ngx-skeleton-base)',
    highlightColor: 'var(--ngx-skeleton-highlight)',
    borderRadius: '8px',
};
const SKELETON_CONFIG = new InjectionToken('SKELETON_CONFIG');

class SkeletonTable {
    globalConfig;
    rows = 5;
    columns = 4;
    config = {};
    constructor(globalConfig) {
        this.globalConfig = globalConfig;
    }
    get settings() {
        return {
            ...DEFAULT_SKELETON_CONFIG,
            ...(this.globalConfig ?? {}),
            ...this.config,
        };
    }
    get rowItems() {
        return Array.from({ length: this.rows });
    }
    get columnItems() {
        return Array.from({ length: this.columns });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonTable, deps: [{ token: SKELETON_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.10", type: SkeletonTable, isStandalone: true, selector: "lib-skeleton-table", inputs: { rows: "rows", columns: "columns", config: "config" }, ngImport: i0, template: "<div class=\"ngx-skeleton-table\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  @for (row of rowItems; track $index) {\n    <div class=\"ngx-skeleton-row\">\n      @for (column of columnItems; track $index) {\n        <div class=\"ngx-skeleton-cell\"></div>\n      }\n    </div>\n  }\n</div>", styles: [".ngx-skeleton-table{width:100%}.ngx-skeleton-row{display:flex;gap:12px;margin-bottom:12px}.ngx-skeleton-cell{height:22px;flex:1;border-radius:6px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonTable, decorators: [{
            type: Component,
            args: [{ selector: 'lib-skeleton-table', imports: [], template: "<div class=\"ngx-skeleton-table\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  @for (row of rowItems; track $index) {\n    <div class=\"ngx-skeleton-row\">\n      @for (column of columnItems; track $index) {\n        <div class=\"ngx-skeleton-cell\"></div>\n      }\n    </div>\n  }\n</div>", styles: [".ngx-skeleton-table{width:100%}.ngx-skeleton-row{display:flex;gap:12px;margin-bottom:12px}.ngx-skeleton-cell{height:22px;flex:1;border-radius:6px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SKELETON_CONFIG]
                }] }], propDecorators: { rows: [{
                type: Input
            }], columns: [{
                type: Input
            }], config: [{
                type: Input
            }] } });

class SkeletonAvatar {
    globalConfig;
    size = 48;
    shape = 'circle';
    config = {};
    constructor(globalConfig) {
        this.globalConfig = globalConfig;
    }
    get settings() {
        return {
            ...DEFAULT_SKELETON_CONFIG,
            ...(this.globalConfig ?? {}),
            ...this.config,
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonAvatar, deps: [{ token: SKELETON_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.10", type: SkeletonAvatar, isStandalone: true, selector: "lib-skeleton-avatar", inputs: { size: "size", shape: "shape", config: "config" }, ngImport: i0, template: "<div\n  class=\"ngx-skeleton-avatar\"\n  [class.ngx-skeleton-avatar-circle]=\"shape === 'circle'\"\n  [class.ngx-skeleton-avatar-square]=\"shape === 'square'\"\n  [style.width.px]=\"size\"\n  [style.height.px]=\"size\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n</div>", styles: [".ngx-skeleton-avatar{display:inline-block;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-avatar-circle{border-radius:50%}.ngx-skeleton-avatar-square{border-radius:10px}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonAvatar, decorators: [{
            type: Component,
            args: [{ selector: 'lib-skeleton-avatar', imports: [], template: "<div\n  class=\"ngx-skeleton-avatar\"\n  [class.ngx-skeleton-avatar-circle]=\"shape === 'circle'\"\n  [class.ngx-skeleton-avatar-square]=\"shape === 'square'\"\n  [style.width.px]=\"size\"\n  [style.height.px]=\"size\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n</div>", styles: [".ngx-skeleton-avatar{display:inline-block;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-avatar-circle{border-radius:50%}.ngx-skeleton-avatar-square{border-radius:10px}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SKELETON_CONFIG]
                }] }], propDecorators: { size: [{
                type: Input
            }], shape: [{
                type: Input
            }], config: [{
                type: Input
            }] } });

class SkeletonCard {
    globalConfig;
    showImage = true;
    lines = 3;
    config = {};
    constructor(globalConfig) {
        this.globalConfig = globalConfig;
    }
    get settings() {
        return {
            ...DEFAULT_SKELETON_CONFIG,
            ...(this.globalConfig ?? {}),
            ...this.config,
        };
    }
    get lineItems() {
        return Array.from({ length: this.lines });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonCard, deps: [{ token: SKELETON_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.10", type: SkeletonCard, isStandalone: true, selector: "lib-skeleton-card", inputs: { showImage: "showImage", lines: "lines", config: "config" }, ngImport: i0, template: "<div class=\"ngx-skeleton-card\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  @if (showImage) {\n    <div class=\"ngx-skeleton-image\"></div>\n  }\n\n  <div class=\"ngx-skeleton-content\">\n    @for (line of lineItems; track $index) {\n      <div\n        class=\"ngx-skeleton-line\"\n        [class.ngx-skeleton-line-short]=\"$index === lineItems.length - 1\">\n      </div>\n    }\n  </div>\n</div>", styles: [".ngx-skeleton-card{width:100%;padding:16px;border-radius:12px;border:1px solid var(--ngx-skeleton-border);background:var(--ngx-skeleton-surface)}.ngx-skeleton-image{height:160px;width:100%;border-radius:10px;margin-bottom:16px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-content{display:flex;flex-direction:column;gap:10px}.ngx-skeleton-line{height:16px;width:100%;border-radius:6px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-line-short{width:65%}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonCard, decorators: [{
            type: Component,
            args: [{ selector: 'lib-skeleton-card', imports: [], template: "<div class=\"ngx-skeleton-card\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  @if (showImage) {\n    <div class=\"ngx-skeleton-image\"></div>\n  }\n\n  <div class=\"ngx-skeleton-content\">\n    @for (line of lineItems; track $index) {\n      <div\n        class=\"ngx-skeleton-line\"\n        [class.ngx-skeleton-line-short]=\"$index === lineItems.length - 1\">\n      </div>\n    }\n  </div>\n</div>", styles: [".ngx-skeleton-card{width:100%;padding:16px;border-radius:12px;border:1px solid var(--ngx-skeleton-border);background:var(--ngx-skeleton-surface)}.ngx-skeleton-image{height:160px;width:100%;border-radius:10px;margin-bottom:16px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-content{display:flex;flex-direction:column;gap:10px}.ngx-skeleton-line{height:16px;width:100%;border-radius:6px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-line-short{width:65%}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SKELETON_CONFIG]
                }] }], propDecorators: { showImage: [{
                type: Input
            }], lines: [{
                type: Input
            }], config: [{
                type: Input
            }] } });

class SkeletonChart {
    globalConfig;
    type = 'bar';
    height = 260;
    bars = 8;
    config = {};
    constructor(globalConfig) {
        this.globalConfig = globalConfig;
    }
    get settings() {
        return {
            ...DEFAULT_SKELETON_CONFIG,
            ...(this.globalConfig ?? {}),
            ...this.config,
        };
    }
    get barItems() {
        return Array.from({ length: this.bars });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonChart, deps: [{ token: SKELETON_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.10", type: SkeletonChart, isStandalone: true, selector: "lib-skeleton-chart", inputs: { type: "type", height: "height", bars: "bars", config: "config" }, ngImport: i0, template: "<div class=\"ngx-skeleton-chart\" [style.height.px]=\"height\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  @if (type === 'bar') {\n    <div class=\"ngx-skeleton-bars\">\n      @for (bar of barItems; track $index) {\n        <div\n          class=\"ngx-skeleton-bar\"\n          [style.height.%]=\"35 + (($index * 13) % 55)\">\n        </div>\n      }\n    </div>\n  }\n\n  @if (type === 'line') {\n    <div class=\"ngx-skeleton-line-chart\">\n      <div class=\"ngx-skeleton-line-path\"></div>\n      <div class=\"ngx-skeleton-line-path small\"></div>\n    </div>\n  }\n\n  @if (type === 'pie') {\n    <div class=\"ngx-skeleton-pie\"></div>\n  }\n</div>", styles: [".ngx-skeleton-chart{width:100%;padding:16px;border-radius:12px;border:1px solid var(--ngx-skeleton-border);background:var(--ngx-skeleton-surface);overflow:hidden}.ngx-skeleton-bars{height:100%;display:flex;align-items:flex-end;gap:12px}.ngx-skeleton-bar{flex:1;min-height:40px;border-radius:8px 8px 4px 4px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-line-chart{position:relative;height:100%}.ngx-skeleton-line-path{position:absolute;left:5%;top:45%;width:90%;height:14px;border-radius:999px;transform:rotate(-8deg);background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-line-path.small{top:62%;width:65%;transform:rotate(6deg)}.ngx-skeleton-pie{width:170px;height:170px;margin:24px auto;border-radius:50%;background:conic-gradient(var(--ngx-skeleton-base) 0deg 90deg,var(--ngx-skeleton-highlight) 90deg 180deg,var(--ngx-skeleton-base) 180deg 270deg,var(--ngx-skeleton-highlight) 270deg 360deg);animation:ngx-skeleton-pulse var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}@keyframes ngx-skeleton-pulse{0%{opacity:.7}50%{opacity:1}to{opacity:.7}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonChart, decorators: [{
            type: Component,
            args: [{ selector: 'lib-skeleton-chart', imports: [], template: "<div class=\"ngx-skeleton-chart\" [style.height.px]=\"height\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  @if (type === 'bar') {\n    <div class=\"ngx-skeleton-bars\">\n      @for (bar of barItems; track $index) {\n        <div\n          class=\"ngx-skeleton-bar\"\n          [style.height.%]=\"35 + (($index * 13) % 55)\">\n        </div>\n      }\n    </div>\n  }\n\n  @if (type === 'line') {\n    <div class=\"ngx-skeleton-line-chart\">\n      <div class=\"ngx-skeleton-line-path\"></div>\n      <div class=\"ngx-skeleton-line-path small\"></div>\n    </div>\n  }\n\n  @if (type === 'pie') {\n    <div class=\"ngx-skeleton-pie\"></div>\n  }\n</div>", styles: [".ngx-skeleton-chart{width:100%;padding:16px;border-radius:12px;border:1px solid var(--ngx-skeleton-border);background:var(--ngx-skeleton-surface);overflow:hidden}.ngx-skeleton-bars{height:100%;display:flex;align-items:flex-end;gap:12px}.ngx-skeleton-bar{flex:1;min-height:40px;border-radius:8px 8px 4px 4px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-line-chart{position:relative;height:100%}.ngx-skeleton-line-path{position:absolute;left:5%;top:45%;width:90%;height:14px;border-radius:999px;transform:rotate(-8deg);background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-line-path.small{top:62%;width:65%;transform:rotate(6deg)}.ngx-skeleton-pie{width:170px;height:170px;margin:24px auto;border-radius:50%;background:conic-gradient(var(--ngx-skeleton-base) 0deg 90deg,var(--ngx-skeleton-highlight) 90deg 180deg,var(--ngx-skeleton-base) 180deg 270deg,var(--ngx-skeleton-highlight) 270deg 360deg);animation:ngx-skeleton-pulse var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}@keyframes ngx-skeleton-pulse{0%{opacity:.7}50%{opacity:1}to{opacity:.7}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SKELETON_CONFIG]
                }] }], propDecorators: { type: [{
                type: Input
            }], height: [{
                type: Input
            }], bars: [{
                type: Input
            }], config: [{
                type: Input
            }] } });

class SkeletonDashboard {
    globalConfig;
    cards = 4;
    showTable = true;
    showChart = true;
    config = {};
    constructor(globalConfig) {
        this.globalConfig = globalConfig;
    }
    get settings() {
        return {
            ...DEFAULT_SKELETON_CONFIG,
            ...(this.globalConfig ?? {}),
            ...this.config,
        };
    }
    get cardItems() {
        return Array.from({ length: this.cards });
    }
    get tableRows() {
        return Array.from({ length: 6 });
    }
    get tableColumns() {
        return Array.from({ length: 5 });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonDashboard, deps: [{ token: SKELETON_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.10", type: SkeletonDashboard, isStandalone: true, selector: "lib-skeleton-dashboard", inputs: { cards: "cards", showTable: "showTable", showChart: "showChart", config: "config" }, ngImport: i0, template: "<div class=\"ngx-skeleton-dashboard\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  <div class=\"ngx-skeleton-dashboard-header\">\n    <div class=\"ngx-skeleton-title\"></div>\n    <div class=\"ngx-skeleton-action\"></div>\n  </div>\n\n  <div class=\"ngx-skeleton-card-grid\">\n    @for (card of cardItems; track $index) {\n      <div class=\"ngx-skeleton-stat-card\">\n        <div class=\"ngx-skeleton-stat-title\"></div>\n        <div class=\"ngx-skeleton-stat-value\"></div>\n      </div>\n    }\n  </div>\n\n  @if (showChart) {\n    <div class=\"ngx-skeleton-chart-box\">\n      <div class=\"ngx-skeleton-bars\">\n        <div class=\"ngx-skeleton-bar bar-1\"></div>\n        <div class=\"ngx-skeleton-bar bar-2\"></div>\n        <div class=\"ngx-skeleton-bar bar-3\"></div>\n        <div class=\"ngx-skeleton-bar bar-4\"></div>\n        <div class=\"ngx-skeleton-bar bar-5\"></div>\n        <div class=\"ngx-skeleton-bar bar-6\"></div>\n      </div>\n    </div>\n  }\n\n  @if (showTable) {\n    <div class=\"ngx-skeleton-table-box\">\n      @for (row of tableRows; track $index) {\n        <div class=\"ngx-skeleton-table-row\">\n          @for (column of tableColumns; track $index) {\n            <div class=\"ngx-skeleton-table-cell\"></div>\n          }\n        </div>\n      }\n    </div>\n  }\n</div>", styles: [".ngx-skeleton-dashboard{width:100%}.ngx-skeleton-dashboard-header{display:flex;justify-content:space-between;gap:16px;margin-bottom:20px}.ngx-skeleton-title{width:220px;height:28px;border-radius:8px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-action{width:120px;height:36px;border-radius:8px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-card-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:20px}.ngx-skeleton-stat-card,.ngx-skeleton-chart-box,.ngx-skeleton-table-box{border:1px solid var(--ngx-skeleton-border);background:var(--ngx-skeleton-surface);border-radius:14px;padding:16px;-webkit-border-radius:14px;-moz-border-radius:14px;-ms-border-radius:14px;-o-border-radius:14px}.ngx-skeleton-stat-title{width:60%;height:16px;border-radius:999px;margin-bottom:16px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-stat-value{width:40%;height:28px;border-radius:8px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-chart-box{height:260px;margin-bottom:20px}.ngx-skeleton-bars{height:100%;display:flex;align-items:flex-end;gap:14px}.ngx-skeleton-bar{flex:1;border-radius:8px 8px 4px 4px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.bar-1{height:45%}.bar-2{height:70%}.bar-3{height:55%}.bar-4{height:85%}.bar-5{height:62%}.bar-6{height:75%}.ngx-skeleton-table-row{display:flex;gap:12px;margin-bottom:12px}.ngx-skeleton-table-cell{height:20px;flex:1;border-radius:6px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}@media(max-width:992px){.ngx-skeleton-card-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:576px){.ngx-skeleton-dashboard-header{flex-direction:column}.ngx-skeleton-card-grid{grid-template-columns:1fr}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonDashboard, decorators: [{
            type: Component,
            args: [{ selector: 'lib-skeleton-dashboard', imports: [], template: "<div class=\"ngx-skeleton-dashboard\"\n  [style.--ngx-skeleton-base]=\"settings.baseColor\"\n  [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n  [style.--ngx-skeleton-duration]=\"settings.animationDuration\"\n  [style.border-radius]=\"settings.borderRadius\">\n  <div class=\"ngx-skeleton-dashboard-header\">\n    <div class=\"ngx-skeleton-title\"></div>\n    <div class=\"ngx-skeleton-action\"></div>\n  </div>\n\n  <div class=\"ngx-skeleton-card-grid\">\n    @for (card of cardItems; track $index) {\n      <div class=\"ngx-skeleton-stat-card\">\n        <div class=\"ngx-skeleton-stat-title\"></div>\n        <div class=\"ngx-skeleton-stat-value\"></div>\n      </div>\n    }\n  </div>\n\n  @if (showChart) {\n    <div class=\"ngx-skeleton-chart-box\">\n      <div class=\"ngx-skeleton-bars\">\n        <div class=\"ngx-skeleton-bar bar-1\"></div>\n        <div class=\"ngx-skeleton-bar bar-2\"></div>\n        <div class=\"ngx-skeleton-bar bar-3\"></div>\n        <div class=\"ngx-skeleton-bar bar-4\"></div>\n        <div class=\"ngx-skeleton-bar bar-5\"></div>\n        <div class=\"ngx-skeleton-bar bar-6\"></div>\n      </div>\n    </div>\n  }\n\n  @if (showTable) {\n    <div class=\"ngx-skeleton-table-box\">\n      @for (row of tableRows; track $index) {\n        <div class=\"ngx-skeleton-table-row\">\n          @for (column of tableColumns; track $index) {\n            <div class=\"ngx-skeleton-table-cell\"></div>\n          }\n        </div>\n      }\n    </div>\n  }\n</div>", styles: [".ngx-skeleton-dashboard{width:100%}.ngx-skeleton-dashboard-header{display:flex;justify-content:space-between;gap:16px;margin-bottom:20px}.ngx-skeleton-title{width:220px;height:28px;border-radius:8px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-action{width:120px;height:36px;border-radius:8px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-card-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:20px}.ngx-skeleton-stat-card,.ngx-skeleton-chart-box,.ngx-skeleton-table-box{border:1px solid var(--ngx-skeleton-border);background:var(--ngx-skeleton-surface);border-radius:14px;padding:16px;-webkit-border-radius:14px;-moz-border-radius:14px;-ms-border-radius:14px;-o-border-radius:14px}.ngx-skeleton-stat-title{width:60%;height:16px;border-radius:999px;margin-bottom:16px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-stat-value{width:40%;height:28px;border-radius:8px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.ngx-skeleton-chart-box{height:260px;margin-bottom:20px}.ngx-skeleton-bars{height:100%;display:flex;align-items:flex-end;gap:14px}.ngx-skeleton-bar{flex:1;border-radius:8px 8px 4px 4px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}.bar-1{height:45%}.bar-2{height:70%}.bar-3{height:55%}.bar-4{height:85%}.bar-5{height:62%}.bar-6{height:75%}.ngx-skeleton-table-row{display:flex;gap:12px;margin-bottom:12px}.ngx-skeleton-table-cell{height:20px;flex:1;border-radius:6px;background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}@media(max-width:992px){.ngx-skeleton-card-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:576px){.ngx-skeleton-dashboard-header{flex-direction:column}.ngx-skeleton-card-grid{grid-template-columns:1fr}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SKELETON_CONFIG]
                }] }], propDecorators: { cards: [{
                type: Input
            }], showTable: [{
                type: Input
            }], showChart: [{
                type: Input
            }], config: [{
                type: Input
            }] } });

class SkeletonText {
    globalConfig;
    lines = 3;
    lineHeight = 14;
    gap = 10;
    lastLineWidth = '65%';
    config = {};
    constructor(globalConfig) {
        this.globalConfig = globalConfig;
    }
    get settings() {
        return {
            ...DEFAULT_SKELETON_CONFIG,
            ...(this.globalConfig ?? {}),
            ...this.config,
        };
    }
    get lineItems() {
        return Array.from({ length: this.lines });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonText, deps: [{ token: SKELETON_CONFIG, optional: true }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.10", type: SkeletonText, isStandalone: true, selector: "lib-skeleton-text", inputs: { lines: "lines", lineHeight: "lineHeight", gap: "gap", lastLineWidth: "lastLineWidth", config: "config" }, ngImport: i0, template: "<div class=\"ngx-skeleton-text\" [style.gap.px]=\"gap\">\n  @for (line of lineItems; track $index) {\n    <div\n      class=\"ngx-skeleton-text-line\"\n      [style.height.px]=\"lineHeight\"\n      [style.width]=\"$index === lineItems.length - 1 ? lastLineWidth : '100%'\"\n      [style.border-radius]=\"settings.borderRadius\"\n      [style.--ngx-skeleton-base]=\"settings.baseColor\"\n      [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n      [style.--ngx-skeleton-duration]=\"settings.animationDuration\">\n    </div>\n  }\n</div>", styles: [".ngx-skeleton-text{width:100%;display:flex;flex-direction:column}.ngx-skeleton-text-line{background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonText, decorators: [{
            type: Component,
            args: [{ selector: 'lib-skeleton-text', imports: [], template: "<div class=\"ngx-skeleton-text\" [style.gap.px]=\"gap\">\n  @for (line of lineItems; track $index) {\n    <div\n      class=\"ngx-skeleton-text-line\"\n      [style.height.px]=\"lineHeight\"\n      [style.width]=\"$index === lineItems.length - 1 ? lastLineWidth : '100%'\"\n      [style.border-radius]=\"settings.borderRadius\"\n      [style.--ngx-skeleton-base]=\"settings.baseColor\"\n      [style.--ngx-skeleton-highlight]=\"settings.highlightColor\"\n      [style.--ngx-skeleton-duration]=\"settings.animationDuration\">\n    </div>\n  }\n</div>", styles: [".ngx-skeleton-text{width:100%;display:flex;flex-direction:column}.ngx-skeleton-text-line{background:linear-gradient(90deg,var(--ngx-skeleton-base) 25%,var(--ngx-skeleton-highlight) 50%,var(--ngx-skeleton-base) 75%);background-size:200% 100%;animation:ngx-skeleton-loading var(--ngx-skeleton-duration) infinite}@keyframes ngx-skeleton-loading{0%{background-position:200% 0}to{background-position:-200% 0}}\n"] }]
        }], ctorParameters: () => [{ type: undefined, decorators: [{
                    type: Optional
                }, {
                    type: Inject,
                    args: [SKELETON_CONFIG]
                }] }], propDecorators: { lines: [{
                type: Input
            }], lineHeight: [{
                type: Input
            }], gap: [{
                type: Input
            }], lastLineWidth: [{
                type: Input
            }], config: [{
                type: Input
            }] } });

class SkeletonWrapper {
    loading = false;
    skeleton = 'text';
    config = {};
    rows = 5;
    columns = 4;
    lines = 3;
    cards = 4;
    chartType = 'bar';
    chartHeight = 260;
    avatarSize = 48;
    avatarShape = 'circle';
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonWrapper, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.10", type: SkeletonWrapper, isStandalone: true, selector: "lib-skeleton-wrapper", inputs: { loading: "loading", skeleton: "skeleton", config: "config", rows: "rows", columns: "columns", lines: "lines", cards: "cards", chartType: "chartType", chartHeight: "chartHeight", avatarSize: "avatarSize", avatarShape: "avatarShape" }, ngImport: i0, template: "@if (loading) {\n  @switch (skeleton) {\n    @case ('table') {\n      <lib-skeleton-table\n        [rows]=\"rows\"\n        [columns]=\"columns\"\n        [config]=\"config\">\n      </lib-skeleton-table>\n    }\n\n    @case ('card') {\n      <lib-skeleton-card\n        [lines]=\"lines\"\n        [config]=\"config\">\n      </lib-skeleton-card>\n    }\n\n    @case ('chart') {\n      <lib-skeleton-chart\n        [type]=\"chartType\"\n        [height]=\"chartHeight\"\n        [config]=\"config\">\n      </lib-skeleton-chart>\n    }\n\n    @case ('dashboard') {\n      <lib-skeleton-dashboard\n        [cards]=\"cards\"\n        [config]=\"config\">\n      </lib-skeleton-dashboard>\n    }\n\n    @case ('avatar') {\n      <lib-skeleton-avatar\n        [size]=\"avatarSize\"\n        [shape]=\"avatarShape\"\n        [config]=\"config\">\n      </lib-skeleton-avatar>\n    }\n\n    @default {\n      <lib-skeleton-text\n        [lines]=\"lines\"\n        [config]=\"config\">\n      </lib-skeleton-text>\n    }\n  }\n} @else {\n  <ng-content></ng-content>\n}", styles: [":host{display:block}\n"], dependencies: [{ kind: "component", type: SkeletonTable, selector: "lib-skeleton-table", inputs: ["rows", "columns", "config"] }, { kind: "component", type: SkeletonCard, selector: "lib-skeleton-card", inputs: ["showImage", "lines", "config"] }, { kind: "component", type: SkeletonChart, selector: "lib-skeleton-chart", inputs: ["type", "height", "bars", "config"] }, { kind: "component", type: SkeletonDashboard, selector: "lib-skeleton-dashboard", inputs: ["cards", "showTable", "showChart", "config"] }, { kind: "component", type: SkeletonText, selector: "lib-skeleton-text", inputs: ["lines", "lineHeight", "gap", "lastLineWidth", "config"] }, { kind: "component", type: SkeletonAvatar, selector: "lib-skeleton-avatar", inputs: ["size", "shape", "config"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonWrapper, decorators: [{
            type: Component,
            args: [{ selector: 'lib-skeleton-wrapper', imports: [
                        SkeletonTable,
                        SkeletonCard,
                        SkeletonChart,
                        SkeletonDashboard,
                        SkeletonText,
                        SkeletonAvatar,
                    ], template: "@if (loading) {\n  @switch (skeleton) {\n    @case ('table') {\n      <lib-skeleton-table\n        [rows]=\"rows\"\n        [columns]=\"columns\"\n        [config]=\"config\">\n      </lib-skeleton-table>\n    }\n\n    @case ('card') {\n      <lib-skeleton-card\n        [lines]=\"lines\"\n        [config]=\"config\">\n      </lib-skeleton-card>\n    }\n\n    @case ('chart') {\n      <lib-skeleton-chart\n        [type]=\"chartType\"\n        [height]=\"chartHeight\"\n        [config]=\"config\">\n      </lib-skeleton-chart>\n    }\n\n    @case ('dashboard') {\n      <lib-skeleton-dashboard\n        [cards]=\"cards\"\n        [config]=\"config\">\n      </lib-skeleton-dashboard>\n    }\n\n    @case ('avatar') {\n      <lib-skeleton-avatar\n        [size]=\"avatarSize\"\n        [shape]=\"avatarShape\"\n        [config]=\"config\">\n      </lib-skeleton-avatar>\n    }\n\n    @default {\n      <lib-skeleton-text\n        [lines]=\"lines\"\n        [config]=\"config\">\n      </lib-skeleton-text>\n    }\n  }\n} @else {\n  <ng-content></ng-content>\n}", styles: [":host{display:block}\n"] }]
        }], propDecorators: { loading: [{
                type: Input
            }], skeleton: [{
                type: Input
            }], config: [{
                type: Input
            }], rows: [{
                type: Input
            }], columns: [{
                type: Input
            }], lines: [{
                type: Input
            }], cards: [{
                type: Input
            }], chartType: [{
                type: Input
            }], chartHeight: [{
                type: Input
            }], avatarSize: [{
                type: Input
            }], avatarShape: [{
                type: Input
            }] } });

class SkeletonDirective {
    templateRef;
    viewContainer;
    isLoading = false;
    skeletonType = 'text';
    set loading(value) {
        this.isLoading = value;
        this.updateView();
    }
    set type(value) {
        this.skeletonType = value;
        this.updateView();
    }
    constructor(templateRef, viewContainer) {
        this.templateRef = templateRef;
        this.viewContainer = viewContainer;
    }
    updateView() {
        this.viewContainer.clear();
        if (this.isLoading) {
            const skeletonRef = this.viewContainer.createComponent(SkeletonWrapper);
            skeletonRef.instance.loading = true;
            skeletonRef.instance.skeleton = this.skeletonType;
        }
        else {
            this.viewContainer.createEmbeddedView(this.templateRef);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonDirective, deps: [{ token: i0.TemplateRef }, { token: i0.ViewContainerRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.10", type: SkeletonDirective, isStandalone: true, selector: "[ngxSkeleton]", inputs: { loading: ["ngxSkeleton", "loading"], type: ["ngxSkeletonType", "type"] }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: SkeletonDirective, decorators: [{
            type: Directive,
            args: [{
                    selector: '[ngxSkeleton]',
                }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }, { type: i0.ViewContainerRef }], propDecorators: { loading: [{
                type: Input,
                args: ['ngxSkeleton']
            }], type: [{
                type: Input,
                args: ['ngxSkeletonType']
            }] } });

class NgxDashboardSkeleton {
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: NgxDashboardSkeleton, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.2.10", type: NgxDashboardSkeleton, isStandalone: true, selector: "lib-ngx-dashboard-skeleton", ngImport: i0, template: `
    <p>
      ngx-dashboard-skeleton works!
    </p>
  `, isInline: true, styles: [""] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.10", ngImport: i0, type: NgxDashboardSkeleton, decorators: [{
            type: Component,
            args: [{ selector: 'lib-ngx-dashboard-skeleton', imports: [], template: `
    <p>
      ngx-dashboard-skeleton works!
    </p>
  ` }]
        }] });

/*
 * Public API Surface of ngx-dashboard-skeleton
 */

/**
 * Generated bundle index. Do not edit.
 */

export { DEFAULT_SKELETON_CONFIG, NgxDashboardSkeleton, SKELETON_CONFIG, SkeletonAvatar, SkeletonCard, SkeletonChart, SkeletonDashboard, SkeletonDirective, SkeletonTable, SkeletonText, SkeletonWrapper };
//# sourceMappingURL=ngx-dashboard-skeleton.mjs.map
