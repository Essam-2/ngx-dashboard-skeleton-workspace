import * as i0 from '@angular/core';
import { InjectionToken, TemplateRef, ViewContainerRef } from '@angular/core';

interface SkeletonConfig {
    animationDuration?: string;
    baseColor?: string;
    highlightColor?: string;
    borderRadius?: string;
}
declare const DEFAULT_SKELETON_CONFIG: Required<SkeletonConfig>;
declare const SKELETON_CONFIG: InjectionToken<SkeletonConfig>;

type SkeletonAvatarShape = 'circle' | 'square';
declare class SkeletonAvatar {
    private globalConfig;
    size: number;
    shape: SkeletonAvatarShape;
    config: SkeletonConfig;
    constructor(globalConfig: SkeletonConfig | null);
    get settings(): Required<SkeletonConfig>;
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonAvatar, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonAvatar, "lib-skeleton-avatar", never, { "size": { "alias": "size"; "required": false; }; "shape": { "alias": "shape"; "required": false; }; "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

type SkeletonChartType = 'bar' | 'line' | 'pie';
declare class SkeletonChart {
    private globalConfig;
    type: SkeletonChartType;
    height: number;
    bars: number;
    config: SkeletonConfig;
    constructor(globalConfig: SkeletonConfig | null);
    get settings(): Required<SkeletonConfig>;
    get barItems(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonChart, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonChart, "lib-skeleton-chart", never, { "type": { "alias": "type"; "required": false; }; "height": { "alias": "height"; "required": false; }; "bars": { "alias": "bars"; "required": false; }; "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

type SkeletonWrapperType = 'table' | 'card' | 'chart' | 'dashboard' | 'text' | 'avatar';
declare class SkeletonWrapper {
    loading: boolean;
    skeleton: SkeletonWrapperType;
    config: SkeletonConfig;
    rows: number;
    columns: number;
    lines: number;
    cards: number;
    chartType: SkeletonChartType;
    chartHeight: number;
    avatarSize: number;
    avatarShape: SkeletonAvatarShape;
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonWrapper, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonWrapper, "lib-skeleton-wrapper", never, { "loading": { "alias": "loading"; "required": false; }; "skeleton": { "alias": "skeleton"; "required": false; }; "config": { "alias": "config"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "lines": { "alias": "lines"; "required": false; }; "cards": { "alias": "cards"; "required": false; }; "chartType": { "alias": "chartType"; "required": false; }; "chartHeight": { "alias": "chartHeight"; "required": false; }; "avatarSize": { "alias": "avatarSize"; "required": false; }; "avatarShape": { "alias": "avatarShape"; "required": false; }; }, {}, never, ["*"], true, never>;
}

declare class SkeletonDirective {
    private templateRef;
    private viewContainer;
    private isLoading;
    private skeletonType;
    set loading(value: boolean);
    set type(value: 'table' | 'card' | 'chart' | 'dashboard' | 'text' | 'avatar');
    constructor(templateRef: TemplateRef<unknown>, viewContainer: ViewContainerRef);
    private updateView;
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<SkeletonDirective, "[ngxSkeleton]", never, { "loading": { "alias": "ngxSkeleton"; "required": false; }; "type": { "alias": "ngxSkeletonType"; "required": false; }; }, {}, never, never, true, never>;
}

declare class NgxDashboardSkeleton {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxDashboardSkeleton, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<NgxDashboardSkeleton, "lib-ngx-dashboard-skeleton", never, {}, {}, never, never, true, never>;
}

declare class SkeletonTable {
    private globalConfig;
    rows: number;
    columns: number;
    config: SkeletonConfig;
    constructor(globalConfig: SkeletonConfig | null);
    get settings(): Required<SkeletonConfig>;
    get rowItems(): number[];
    get columnItems(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonTable, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonTable, "lib-skeleton-table", never, { "rows": { "alias": "rows"; "required": false; }; "columns": { "alias": "columns"; "required": false; }; "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SkeletonCard {
    private globalConfig;
    showImage: boolean;
    lines: number;
    config: SkeletonConfig;
    constructor(globalConfig: SkeletonConfig | null);
    get settings(): Required<SkeletonConfig>;
    get lineItems(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonCard, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonCard, "lib-skeleton-card", never, { "showImage": { "alias": "showImage"; "required": false; }; "lines": { "alias": "lines"; "required": false; }; "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SkeletonText {
    private globalConfig;
    lines: number;
    lineHeight: number;
    gap: number;
    lastLineWidth: string;
    config: SkeletonConfig;
    constructor(globalConfig: SkeletonConfig | null);
    get settings(): Required<SkeletonConfig>;
    get lineItems(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonText, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonText, "lib-skeleton-text", never, { "lines": { "alias": "lines"; "required": false; }; "lineHeight": { "alias": "lineHeight"; "required": false; }; "gap": { "alias": "gap"; "required": false; }; "lastLineWidth": { "alias": "lastLineWidth"; "required": false; }; "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

declare class SkeletonDashboard {
    private globalConfig;
    cards: number;
    showTable: boolean;
    showChart: boolean;
    config: SkeletonConfig;
    constructor(globalConfig: SkeletonConfig | null);
    get settings(): Required<SkeletonConfig>;
    get cardItems(): number[];
    get tableRows(): number[];
    get tableColumns(): number[];
    static ɵfac: i0.ɵɵFactoryDeclaration<SkeletonDashboard, [{ optional: true; }]>;
    static ɵcmp: i0.ɵɵComponentDeclaration<SkeletonDashboard, "lib-skeleton-dashboard", never, { "cards": { "alias": "cards"; "required": false; }; "showTable": { "alias": "showTable"; "required": false; }; "showChart": { "alias": "showChart"; "required": false; }; "config": { "alias": "config"; "required": false; }; }, {}, never, never, true, never>;
}

export { DEFAULT_SKELETON_CONFIG, NgxDashboardSkeleton, SKELETON_CONFIG, SkeletonAvatar, SkeletonCard, SkeletonChart, SkeletonDashboard, SkeletonDirective, SkeletonTable, SkeletonText, SkeletonWrapper };
export type { SkeletonAvatarShape, SkeletonChartType, SkeletonConfig, SkeletonWrapperType };
